package ba.edu.ssst;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws FileNotFoundException {
        try {
            File file = new File("employees.txt");
            Scanner s = new Scanner(file);

            Map<String, ArrayList<Employee>> map = new HashMap<>();

            while (s.hasNextLine()) {
                String line = s.nextLine();
                String[] elements = line.split(",");

                if (elements.length == 4) {
                    String ime = elements[0].trim();
                    String prezime = elements[1].trim();
                    String dep = elements[2].trim();

                    Employee e = new Employee(ime, prezime);
                    Department d = new Department(dep);



                    if (map.containsKey(d.getName())) {
                        ArrayList<Employee> employees = map.get(d.getName());
                        employees.add(e);
                        map.put(d.getName(), employees);
                    } else {
                        ArrayList<Employee> employees = new ArrayList<>();
                        employees.add(e);
                        map.put(d.getName(), employees);
                    }
                }
            }

            System.out.println("Outputting to a file...");


           PrintWriter pw = new PrintWriter("dep1.txt");
            PrintWriter pw2 = new PrintWriter("dep2.txt");
            map.forEach((k,v) -> {
                pw.println(String.format("Department %s has following employees:", k));
                for(Employee e : v) {
                    pw.println(e);
                }
                pw.close();
                pw2.println(String.format("Department %s has following employees:", k));
                for(Employee e : v) {
                    pw2.println(e);
                }
                pw2.close();
            });
/*
            map.forEach((k,v) -> {
                pw2.println(String.format("Department %s has following employees:", k));
                for(Employee e : v) {
                    pw2.println(e);
                }
                pw2.close();
            });

            map.forEach((k, v) -> {
                System.out.println(String.format("Department %s has following members:", k));
                for (Employee employee : v) {
                    System.out.println(employee);
                }
                System.out.println("====================================");
            });
*/
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
