package ba.edu.ssst;

import java.util.ArrayList;

public class HighestSalaryThread implements Runnable {

    ArrayList<Employee> lista = new ArrayList<>();

    public HighestSalaryThread(ArrayList<Employee> lista) {
        this.lista = lista;
    }

    @Override
    public void run() {

    for(Employee e : lista) {
        int highest = lista.get(0).getSalary();
        if(e.getSalary() > highest) highest = e.getSalary();
        Sync.displayLargest(highest);
    }
    }
}
