package ba.edu.ssst;

public class Sync {
    static Object obj = new Object();

    public static Integer largest = 0;
    public static Integer lowest = 0;

    public static void displayLargest(Integer newSalary) {
        synchronized (obj) {
            largest = newSalary;
        }
    }

    public static void displayLowestt(Integer newSalary) {
        synchronized (obj) {
            lowest = newSalary;
        }
    }

}
