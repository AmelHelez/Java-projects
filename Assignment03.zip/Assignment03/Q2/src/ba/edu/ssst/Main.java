package ba.edu.ssst;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws FileNotFoundException, InterruptedException {
        File file = new File("employees.txt");
        Scanner s = new Scanner(file);
        ArrayList<Employee> employees = new ArrayList<>();

        while(s.hasNextLine()) {
            String line = s.nextLine();
            String[] elements = line.split(", ");
            if(elements.length == 4) {
                String ime = elements[0].trim();
                String prezime = elements[1].trim();
                String dep = elements[2].trim();
                Integer salary = Integer.parseInt(elements[3].trim());

                Employee employee = new Employee(ime,prezime,dep,salary);

                employees.add(employee);
                }
            }

/*
        for(Employee e : employees) {
            System.out.println(e);
        }
*/
        HighestSalaryThread hs = new HighestSalaryThread(employees);
        Thread t1 = new Thread(hs);
        t1.start();
        t1.join();


        LowestSalaryThread ls = new LowestSalaryThread(employees);
        Thread t2 = new Thread(ls);
        t2.start();
        t2.join();

        System.out.println("The highest salary is: " + Sync.largest);

        System.out.println("\nThe lowest salary is " + Sync.lowest);
    }
}
