package ba.edu.ssst;

import java.util.ArrayList;

public class LowestSalaryThread implements Runnable {
    ArrayList<Employee> employees = new ArrayList<>();

    public LowestSalaryThread(ArrayList<Employee> employees) {
        this.employees = employees;
    }

    @Override
    public void run() {
    for(Employee e : employees) {
        int lowestSalary = employees.get(0).getSalary();
        if(e.getSalary() < lowestSalary) lowestSalary = e.getSalary();
        Sync.displayLowestt(lowestSalary);
    }
    }
}
