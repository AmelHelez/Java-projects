package ba.edu.ssst;

import java.util.ArrayList;

public class Storage {
    private static Storage instance;

    public ArrayList<Employee> employees;
    public ArrayList<Manager> managers;

    private Storage() {
        this.employees = new ArrayList<>();
        this.managers = new ArrayList<>();
    }

    public static Storage getInstance() {
        if(instance == null) {
            instance = new Storage();
        }
        return instance;
    }
}
