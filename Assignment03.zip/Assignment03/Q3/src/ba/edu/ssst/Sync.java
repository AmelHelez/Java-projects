package ba.edu.ssst;

public class Sync {
    public static Object obj = new Object();
    public static int total;


    public static void display(int t) {
        synchronized (obj) {
            total = t;
        }
    }
}
