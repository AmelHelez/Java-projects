package ba.edu.ssst;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class TotalSalariesThread implements Runnable {
    ArrayList<Employee> employees = new ArrayList<>();
    ArrayList<Manager> managers = new ArrayList<>();
    int total1 = 0;
    int total2 = 0;
    int razlika = 0;

    public TotalSalariesThread(ArrayList<Employee> employees) {
        this.employees = employees;
    }

    @Override
    public void run() {
        for (Employee e : employees) {
            Map<String,Integer> mapa = new HashMap<>();

            }

        }


}



