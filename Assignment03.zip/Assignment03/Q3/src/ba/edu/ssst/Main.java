package ba.edu.ssst;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws FileNotFoundException, InterruptedException {
        File file = new File("employees.txt");
        Scanner s = new Scanner(file);
        ArrayList<Employee> list = new ArrayList<>();

        while(s.hasNextLine()) {
            String line = s.nextLine();
            String[] elements = line.split(", ");
            if(elements.length == 4) {
                String fname = elements[0].trim();
                String lname = elements[1].trim();
                String dep = elements[2].trim();
                Integer salary = Integer.parseInt(elements[3]);

                Employee employee = new Employee(fname,lname,dep,salary);

                list.add(employee);
                Storage.getInstance().employees.add(employee);
            }
        }

       /* for(Employee e : list) {
            System.out.println(e);
        } */

       File f = new File("managers.txt");
       Scanner scanner = new Scanner(f);
       ArrayList<Manager> managers = new ArrayList<>();

       while(scanner.hasNextLine()) {
           String lajn = scanner.nextLine();
           String[] elem = lajn.split(", ");
           if(elem.length == 3) {
               String dep = elem[0].trim();
               String name = elem[1].trim();
               Integer budget = Integer.parseInt(elem[2].trim());

               Manager manager = new Manager(dep,name,budget);

               managers.add(manager);
               Storage.getInstance().managers.add(manager);
           }
       }
/*
       TotalSalariesThread ts = new TotalSalariesThread(list,managers);
       Thread t1 = new Thread(ts);
       t1.start();
       t1.join();

       System.out.println(Sync.total1);
/*
       for(Manager m : managers) {
           System.out.println(m); //just to check if everything is correct
       } */
     System.out.println(Sync.total);




    }
}
