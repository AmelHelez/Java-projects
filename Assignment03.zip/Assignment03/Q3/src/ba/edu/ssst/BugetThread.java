package ba.edu.ssst;

public class BugetThread implements Runnable{

    @Override
    public void run() {

    }
}
