package ba.edu.ssst;

import java.util.ArrayList;
import java.io.File;

public class Team {
    private String teamName;
    ArrayList<TeamMember> members;

    public Team(String teamName) {
        this.teamName = teamName;
        members = new ArrayList<>();
   }

   public String getTeamName() {
        return teamName;
   }

}


