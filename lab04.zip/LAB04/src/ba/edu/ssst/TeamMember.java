package ba.edu.ssst;

import java.io.File;

public class TeamMember{
    private final String f_name;
    private final String l_name;
    private final Boolean captain;

    public TeamMember(String f_name,String l_name,Boolean captain) {
        this.f_name = f_name;
        this.l_name = l_name;
        this.captain = captain;
    }

    public String getFName() {
        return this.f_name;
    }

    public String getLName() {
        return this.l_name;
    }

    public Boolean isCaptain() {
        return this.captain;
    }

    @Override
    public String toString() {
        return f_name + " " + l_name + " [" + captain + "].";
    }
}
