package ba.edu.ssst;

import java.io.File;
import java.util.Scanner;
import java.security.InvalidParameterException;


public class Main {

    public static void main(String[] args) {
        File file = new File("teams.txt");

        try {
            Scanner s = new Scanner(file);

            while(s.hasNextLine()) {
                String name = s.nextLine();
                String[] nameLineSplit = name.split(",");
                if(nameLineSplit.length == 1) {
                    Team t = new Team(nameLineSplit[0]);
                    Storage.getInstance().teams.add(t);
                    
                }
            }
        }

        catch(InvalidParameterException e) {
            System.out.println(e.getMessage());
        } catch(Exception e) {
            System.out.println("No file found.");
        }
    }

}
