package ba.edu.ssst;

public abstract class Animal {
    String name;
    String sound;

    public String makeSound() {
        return null;
    }

    public String showPicture() {
        return null;
    }
}
