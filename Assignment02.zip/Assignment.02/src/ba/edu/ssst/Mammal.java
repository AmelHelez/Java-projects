package ba.edu.ssst;

public class Mammal extends Animal {
    String breed;
    public String getBreed() {
        return breed;
    }
}
