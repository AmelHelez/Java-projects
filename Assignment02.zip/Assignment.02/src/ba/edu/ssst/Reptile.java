package ba.edu.ssst;

public class Reptile extends Animal {
    Boolean dangerous;
    public Boolean isDangerous() {
        return dangerous;
    }

}
