package ba.edu.ssst;

public class Threadd implements Runnable{

    private int start;
    private int end;

    public Threadd(int start, int end) {
        this.start = start;
        this.end = end;
    }

    @Override
    public void run() {
        for(int i = start; i < end; i++) {
            int nr = Singleton.getInstance().erej.get(i);
            Singleton.getInstance().erej.set(i,nr + 10);
        }
    }
}
