package ba.edu.ssst;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Main {

    public static void main(String[] args) {
        Random r = new Random();
        int nr;
        int sum = 0;
        for(int i = 0; i < 1000; i++) {
            nr = r.nextInt(20);
            Singleton.getInstance().erej.add(nr);
            sum += nr;
        }
        System.out.println(sum);
        System.out.println(Singleton.getInstance().erej);

        ArrayList<Thread> erej2 = new ArrayList<>();
        for(int i = 0; i < 5; i++) {
            Threadd t = new Threadd(i * 200,200 + i * 200);
            Thread thr = new Thread(t);
            thr.start();
            erej2.add(thr);
        }

        erej2.forEach(thr -> {
            try {
                thr.join();

            } catch(InterruptedException e) {
                e.printStackTrace();
            }
        });

        int newSum = 0;
        for(int i = 0; i < 1000; i++) {
            newSum += Singleton.getInstance().erej.get(i);
        }

        System.out.println("The sum is: " + newSum );
    }
}
