package ba.edu.ssst;

public class Main {

    public static void main(String[] args) {
    }
}
