package ba.edu.ssst;

import java.util.ArrayList;

public class CountThread implements Runnable {

    ArrayList<>

    public CountThread(int start, int end) {
        this.start = start;
        this.end = end;
    }
    @Override
    public void run() {

    }
}
