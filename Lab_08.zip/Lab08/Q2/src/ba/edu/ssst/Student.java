package ba.edu.ssst;

public class Student {
    private final String first_name;
    private final String last_name;
    private int num_of_points;

    public Student(String first_name, String last_name, int num_of_points) {
        this.first_name = first_name;
        this.last_name = last_name;
        if(num_of_points < 1 || num_of_points > 10)
            throw new IllegalArgumentException("The number must be between 1 and 10!");
        this.num_of_points = num_of_points;
    }

    public int getPoints() {
        return num_of_points;
    }

    public String getFirst_name() {
        return first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    @Override
    public String toString() {
        return "Name: " + first_name + " " + last_name
                + "\nNumber of points: " + num_of_points;
    }


}
