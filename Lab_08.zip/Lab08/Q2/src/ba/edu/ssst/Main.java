package ba.edu.ssst;

import java.util.ArrayList;
import java.util.Map;
import java.util.TreeMap;

public class Main {

    public static void main(String[] args) {
     Map map = new TreeMap<Student,Integer>();
     ArrayList<Student> students = new ArrayList<>();
     Student s1 = new Student("Amel","Helez",10);
     students.add(s1);
     students.add(new Student("Filip","Junior",8));
     students.add(new Student("Edim","Hadzic",9));
     students.add(new Student("Abdulah","Zeljo",3));
     students.add(new Student("Ena","Scarlett",9));
     students.add(new Student("Rijad","Logo",8));
     students.add(new Student("Zafar","Beck",6));
        for (Student s: students) {
            System.out.println(s);
        }

        for(Student s : students) {
            if(map.containsKey(s.getPoints())) {
                Integer value = (Integer) map.get(s.getPoints());
                map.put(s.getPoints(),value + 1);
            } else {
                map.put(s.getPoints(),1);
            }
        }

        map.forEach((k,v) -> System.out.println(k + " points has/have " + v + " student(s)."));
    }
}
